# LangDeckGenerator
A Python script for creating Language Anki cards. Based on corpus text in a specified language, this is based on the work of errbufferoverfl/pearl-memory
